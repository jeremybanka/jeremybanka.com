# To Use in Visual Studio Code...

Install Sudo. If it warns you, don't worry.

in VS code:

    Code > Preferences > ••• > Open settings.json

Copy & Paste

    "editor.fontFamily": "Sudo",
    "editor.fontSize": 13,
    "editor.fontLigatures": true
